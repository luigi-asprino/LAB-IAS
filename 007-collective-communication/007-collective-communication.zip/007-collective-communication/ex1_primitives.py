# =============================================================================
# ex1_primitives.py — Esercizio 1: Primitive collettive con torch.distributed
# =============================================================================
#
# Obiettivo: osservare direttamente broadcast, reduce e all-reduce senza
# wrapping DDP. Lo script deve essere lanciato con torchrun:
#
#   torchrun --nproc_per_node=2 ex1_primitives.py
#   torchrun --nproc_per_node=4 ex1_primitives.py
#
# Cosa osservare:
#   - Dopo broadcast: tutti i rank hanno lo stesso tensore (quello del rank 0)
#   - Dopo all_reduce(SUM): ogni rank ha la SOMMA dei contributi di tutti
#   - Dopo all_reduce(MEDIA): ogni rank ha la MEDIA globale
#   - Se commenti una chiamata dist.*() per un rank → deadlock garantito
#
# Nota sul backend:
#   Usiamo "gloo" perché funziona su CPU senza CUDA. Su GPU con NCCL il
#   comportamento è identico — cambia solo l'implementazione sotto.
# =============================================================================

import os
import torch
import torch.distributed as dist


# =============================================================================
# SEZIONE 1 — Inizializzazione del processo group
# =============================================================================

def setup() -> tuple[int, int]:
    """
    Inizializza il processo group e restituisce (rank, world_size).

    torchrun inietta automaticamente le variabili:
      RANK        → indice univoco di questo processo (0, 1, ..., N-1)
      WORLD_SIZE  → numero totale di processi
      MASTER_ADDR → hostname del processo rank=0
      MASTER_PORT → porta di coordinamento
      LOCAL_RANK  → rank locale sulla macchina (=RANK in esercizi locali)

    init_process_group() è una BARRIERA IMPLICITA: nessun processo
    procede fino a quando tutti non hanno chiamato questa funzione.
    Se un processo si blocca prima di chiamarla, gli altri aspettano
    per sempre — tipico errore all'avvio.
    """
    dist.init_process_group(
        backend="gloo",     # CPU: gloo | GPU: nccl
        init_method="env://"  # Legge RANK, WORLD_SIZE, MASTER_ADDR da env
    )
    rank       = dist.get_rank()
    world_size = dist.get_world_size()
    print(f"[rank {rank}/{world_size}] Processo avviato")
    return rank, world_size


def teardown():
    """Chiude il processo group in modo pulito."""
    dist.destroy_process_group()


# =============================================================================
# SEZIONE 2 — Broadcast
# =============================================================================

def demo_broadcast(rank: int, world_size: int):
    """
    Broadcast: il rank 0 distribuisce lo stesso dato a tutti i processi.

    Formalizzazione:
        y_i = x_r  ∀ i  dove r = src (rank sorgente)

    Usato in DDP per:
      - Replicare i parametri iniziali da rank 0 a tutti i worker al momento
        del wrapping DDP(model) — garantisce che tutti partano dagli stessi pesi.
      - Diffondere iperparametri globali (learning rate schedules, configurazioni).
    """
    print(f"\n{'='*50}")
    print("BROADCAST")
    print('='*50)

    # Solo rank 0 inizializza con dati reali; gli altri partono da zero.
    # Il broadcast sovrascriverà i tensori degli altri rank con quello di rank 0.
    if rank == 0:
        data = torch.tensor([1.0, 2.0, 3.0, 4.0])
    else:
        data = torch.zeros(4)

    print(f"[rank {rank}] PRIMA del broadcast: {data.tolist()}")

    # dist.broadcast() modifica `data` IN-PLACE su tutti i rank.
    # src=0 indica che il dato "sorgente" è quello del rank 0.
    # TUTTI i rank devono chiamare questa funzione — è collettiva.
    dist.broadcast(data, src=0)

    print(f"[rank {rank}] DOPO  il broadcast: {data.tolist()}")
    # Risultato atteso: tutti i rank stampano [1.0, 2.0, 3.0, 4.0]
    # indipendentemente da quanti processi ci sono.


# =============================================================================
# SEZIONE 3 — Reduce
# =============================================================================

def demo_reduce(rank: int, world_size: int):
    """
    Reduce: aggrega i dati di tutti i processi con ⊕ e porta il risultato
    a un solo processo (dst=0 per convenzione).

    Formalizzazione:
        y_0 = ⊕ x_i  con ⊕ = SUM qui

    Usato per metriche di validazione che devono essere loggate solo dal
    rank 0: si riduce la loss media su rank 0, che poi scrive su TensorBoard
    o stampa senza che gli altri rank si occupino dell'I/O.

    Nota: dopo una reduce, solo dst ha il risultato aggregato.
    Se tutti i rank necessitano del risultato, usare all_reduce.
    """
    print(f"\n{'='*50}")
    print("REDUCE")
    print('='*50)

    # Ogni rank contribuisce con il proprio rank+1 (valore distinto e predicibile)
    local = torch.tensor([float(rank + 1)] * 4)
    print(f"[rank {rank}] PRIMA della reduce: {local.tolist()}")

    dist.reduce(local, dst=0, op=dist.ReduceOp.SUM)

    # Solo rank 0 ha il risultato; gli altri hanno un tensore invariato
    # (comportamento di gloo) oppure indefinito (comportamento di NCCL).
    # MAI leggere il risultato su rank != dst dopo una reduce.
    if rank == 0:
        expected = sum(range(1, world_size + 1))
        print(f"[rank {rank}] DOPO la reduce (dst=0): {local.tolist()}")
        print(f"[rank {rank}] Atteso: [{expected}]*4  → OK={all(v == expected for v in local.tolist())}")
    else:
        print(f"[rank {rank}] DOPO la reduce (non-dst): risultato non definito per questo rank")


# =============================================================================
# SEZIONE 4 — All-Reduce
# =============================================================================

def demo_all_reduce(rank: int, world_size: int):
    """
    All-Reduce: aggrega con ⊕ e porta il risultato a TUTTI i processi.

    Formalizzazione:
        y_i = ⊕_j x_j  ∀ i

    Questa è la primitiva centrale di PyTorch DDP:
      - Ogni rank calcola localmente i gradienti sul proprio batch
      - DDP chiama all_reduce(SUM) su ogni tensore di gradiente
      - Divide per world_size per ottenere la media globale
      - L'optimizer aggiorna i parametri con la media globale

    Il risultato è che tutti i rank hanno gli stessi parametri dopo
    ogni passo dell'optimizer — questo garantisce la coerenza del training.

    NOTA: in DDP questa chiamata avviene IMPLICITAMENTE dentro .backward().
    Qui la vediamo esplicitamente per capire cosa succede sotto.
    """
    print(f"\n{'='*50}")
    print("ALL-REDUCE (SUM)")
    print('='*50)

    local = torch.tensor([float(rank + 1)] * 4)
    print(f"[rank {rank}] PRIMA dell'all-reduce: {local.tolist()}")

    dist.all_reduce(local, op=dist.ReduceOp.SUM)

    expected = float(sum(range(1, world_size + 1)))
    print(f"[rank {rank}] DOPO all-reduce(SUM): {local.tolist()}")
    assert all(abs(v - expected) < 1e-5 for v in local.tolist()), \
        f"Errore: atteso {expected}, ottenuto {local.tolist()}"

    # ── Media globale (come fa DDP) ──────────────────────────────────────
    print(f"\n{'='*50}")
    print("ALL-REDUCE (MEDIA GLOBALE — come DDP)")
    print('='*50)

    # Simulazione del flusso DDP:
    #   1. Ogni rank ha un "gradiente locale" = rank+1
    #   2. All-reduce SUM → somma globale
    #   3. Divisione per world_size → media globale
    local_grad = torch.tensor([float(rank + 1)] * 4)
    print(f"[rank {rank}] Gradiente locale: {local_grad.tolist()}")

    dist.all_reduce(local_grad, op=dist.ReduceOp.SUM)
    local_grad /= world_size

    mean_expected = expected / world_size
    print(f"[rank {rank}] Gradiente medio globale: {local_grad.tolist()}")
    print(f"[rank {rank}] Atteso: [{mean_expected:.2f}]*4  → OK={all(abs(v - mean_expected) < 1e-5 for v in local_grad.tolist())}")


# =============================================================================
# SEZIONE 5 — Gather e All-Gather
# =============================================================================

def demo_gather(rank: int, world_size: int):
    """
    Gather: raccoglie i tensori di tutti i rank su un singolo rank (dst=0).
    All-Gather: raccoglie su TUTTI i rank.

    Gather:     y_0 = (x_0, x_1, ..., x_{N-1})  (solo rank 0)
    All-Gather: y_i = (x_0, x_1, ..., x_{N-1})  ∀ i

    All-gather è usata nella fase 2 (All-Gather) del ring-based all-reduce
    e in FSDP (Fully Sharded Data Parallel) per ricostruire i parametri
    sharded prima del forward pass.
    """
    print(f"\n{'='*50}")
    print("ALL-GATHER")
    print('='*50)

    # Ogni rank contribuisce con un tensore di dimensione 2 con valori distinti
    local = torch.tensor([float(rank * 10), float(rank * 10 + 1)])
    print(f"[rank {rank}] Contributo locale: {local.tolist()}")

    # Prepara la lista di output: world_size tensori della stessa dimensione
    gathered = [torch.zeros(2) for _ in range(world_size)]

    dist.all_gather(gathered, local)

    print(f"[rank {rank}] Risultato all_gather: {[t.tolist() for t in gathered]}")
    # Tutti i rank devono vedere la stessa lista completa


# =============================================================================
# SEZIONE 6 — Scatter
# =============================================================================

def demo_scatter(rank: int, world_size: int):
    """
    Scatter: il rank sorgente (src=0) suddivide un tensore globale in parti
    e ne distribuisce una a ciascun processo.

    y_i = x_i   dove x è la i-esima partizione del tensore su rank 0

    Inverso logico del gather. Usato per distribuire partizioni di dati
    o sotto-vettori dei parametri ai nodi di calcolo.
    """
    print(f"\n{'='*50}")
    print("SCATTER")
    print('='*50)

    # rank 0 prepara i dati da distribuire; gli altri preparano un buffer vuoto
    if rank == 0:
        # Lista di world_size tensori: il rank 0 spedisce scatter_list[i] al rank i
        scatter_list = [torch.tensor([float(i * 100), float(i * 100 + 1)])
                        for i in range(world_size)]
        print(f"[rank 0] Dati da distribuire: {[t.tolist() for t in scatter_list]}")
    else:
        scatter_list = None

    output = torch.zeros(2)
    dist.scatter(output, scatter_list=scatter_list, src=0)

    print(f"[rank {rank}] Ricevuto: {output.tolist()}")
    # rank i deve ricevere [i*100, i*100+1]


# =============================================================================
# SEZIONE 7 — Domanda didattica: cosa succede senza partecipazione totale?
# =============================================================================

def demo_barrier_requirement(rank: int, world_size: int):
    """
    Dimostra che le operazioni collettive richiedono la partecipazione di TUTTI.

    QUESTO BLOCCO È COMMENTATO: se eseguito, causa un deadlock intenzionale.
    Il docente può decommentarlo per mostrare agli studenti cosa succede
    quando un processo non chiama l'operazione collettiva.

    Nel training DDP questo scenario si verifica se:
      - Un worker lancia un'eccezione durante il forward/backward
      - Un worker viene terminato dal sistema operativo (OOM, SIGKILL)
      - Il codice di un rank ha un if/else che salta la chiamata collettiva

    In tutti questi casi il training si blocca indefinitamente (o fino al timeout).
    Questo è il principale limite di fault tolerance dei collective patterns.
    """
    pass
    # ── Decommentare per vedere il deadlock: ─────────────────────────────
    # if rank == 0:
    #     # rank 0 NON chiama all_reduce → gli altri aspettano per sempre
    #     print(f"[rank 0] Volutamente salto l'all-reduce — deadlock imminente!")
    # else:
    #     data = torch.ones(4)
    #     dist.all_reduce(data, op=dist.ReduceOp.SUM)  # si blocca qui
    #     print(f"[rank {rank}] Non vedrò mai questa riga.")


# =============================================================================
# Entry point
# =============================================================================

def main():
    rank, world_size = setup()

    # Piccola pausa per permettere a tutti i processi di stampare
    # l'header prima che inizino le demo (solo cosmetic, non funzionale)
    import time
    time.sleep(0.1 * rank)

    if rank == 0:
        print(f"\n{'#'*60}")
        print(f"# Esercizio 1: Primitive collettive")
        print(f"# world_size = {world_size}")
        print(f"{'#'*60}")

    # Barriera esplicita: tutti i rank partono insieme
    dist.barrier()

    demo_broadcast(rank, world_size)
    dist.barrier()

    demo_reduce(rank, world_size)
    dist.barrier()

    demo_all_reduce(rank, world_size)
    dist.barrier()

    demo_gather(rank, world_size)
    dist.barrier()

    demo_scatter(rank, world_size)
    dist.barrier()

    if rank == 0:
        print(f"\n{'='*50}")
        print("Tutte le primitive completate con successo.")
        print(f"{'='*50}")

    teardown()


if __name__ == "__main__":
    main()
