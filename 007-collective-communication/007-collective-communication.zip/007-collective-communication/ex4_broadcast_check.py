# =============================================================================
# ex4_broadcast_check.py — Esercizio 4 (opzionale): verifica del broadcast
#                          iniziale dei parametri in DDP
# =============================================================================
#
# Obiettivo: dimostrare empiricamente che DDP(model) esegue un broadcast
# dei parametri dal rank 0 a tutti gli altri al momento del wrapping,
# indipendentemente dai seed di inizializzazione di ogni rank.
#
# Lancio:
#   torchrun --nproc_per_node=3 ex4_broadcast_check.py
#
# Cosa osservare:
#   - PRIMA del wrapping DDP: ogni rank ha parametri diversi (seed diverso)
#   - DOPO il wrapping DDP: tutti i rank hanno gli stessi parametri
#     (quelli del rank 0)
#
# Perché questo è importante:
#   Senza questo broadcast, processi con parametri iniziali diversi
#   produrrebbero gradienti su loss-surfaces diverse, rendendo l'all-reduce
#   matematicamente inconsistente. Il broadcast è la precondizione
#   necessaria per la correttezza del training DDP.
# =============================================================================

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

from model import MLP


def setup():
    backend = "nccl" if torch.cuda.is_available() else "gloo"
    dist.init_process_group(backend=backend, init_method="env://")
    return dist.get_rank(), dist.get_world_size()


def teardown():
    dist.destroy_process_group()


def param_signature(model) -> float:
    """
    Firma numerica del modello: somma di tutti i parametri.
    Se due modelli hanno la stessa firma, hanno (quasi certamente)
    gli stessi pesi. Non è un hash crittografico, ma è sufficiente
    per verificare la coerenza in un contesto didattico.
    """
    return sum(p.sum().item() for p in model.parameters())


def main():
    rank, world_size = setup()

    print(f"\n{'='*60}")
    print(f"Verifica broadcast iniziale DDP  —  world_size={world_size}")
    print(f"{'='*60}")

    # ── Inizializzazione con seed DIVERSO per ogni rank ──────────────────
    # Questo simula il caso reale in cui ogni processo viene avviato
    # indipendentemente, senza coordinamento del seed.
    torch.manual_seed(rank * 1000 + 42)
    model = MLP(in_features=128, n_classes=2)

    sig_before = param_signature(model)
    print(f"\n[rank {rank}] Firma parametri PRIMA di DDP: {sig_before:+.4f}")

    # Breve pausa per evitare interleaving dell'output
    import time; time.sleep(0.05 * rank)

    # ── Wrapping DDP: avviene il broadcast da rank 0 ─────────────────────
    # DDP internamente chiama dist.broadcast() su ogni tensore di parametri.
    # Il "src" è sempre rank 0. Dopo questo punto tutti i rank devono avere
    # esattamente gli stessi pesi del rank 0.
    dist.barrier()  # Tutti partono insieme
    model_ddp = DDP(model)
    dist.barrier()  # Tutti hanno completato il wrapping

    sig_after = param_signature(model_ddp.module)
    print(f"[rank {rank}] Firma parametri DOPO  DDP: {sig_after:+.4f}")

    # ── Verifica ─────────────────────────────────────────────────────────
    # Raccoglie le firme di tutti i rank sul rank 0 per confrontarle.
    sig_tensor = torch.tensor([sig_after])
    all_sigs   = [torch.zeros(1) for _ in range(world_size)]
    dist.all_gather(all_sigs, sig_tensor)

    if rank == 0:
        print(f"\n[rank 0] Firme raccolte da tutti i rank:")
        for i, sig in enumerate(all_sigs):
            print(f"  rank {i}: {sig.item():+.4f}")

        unique_before = len({round(s, 4) for s in
                             [sig_before] * world_size})  # placeholder
        all_equal = all(
            abs(s.item() - all_sigs[0].item()) < 1e-3
            for s in all_sigs
        )

        print(f"\n✓ Tutti i rank hanno parametri identici: {all_equal}")
        if all_equal:
            print("  Il broadcast di DDP ha funzionato correttamente.")
        else:
            diffs = [abs(s.item() - all_sigs[0].item()) for s in all_sigs]
            print(f"  Differenze massime: {max(diffs):.6f}")
            print("  Errore inatteso: contattare il docente.")

        print(f"\n{'─'*60}")
        print("Conclusione:")
        print("  PRIMA del wrapping: ogni rank aveva pesi diversi")
        print("  DOPO  il wrapping: tutti i rank hanno i pesi di rank 0")
        print("  Questo è il broadcast implicito di DDP.__init__()")
        print(f"{'─'*60}")

    teardown()


if __name__ == "__main__":
    main()
