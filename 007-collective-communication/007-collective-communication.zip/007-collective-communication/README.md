# Lezione 7 — Collective Communication Pattern su GCP

## Obiettivi

Al termine di questa lezione lo studente sarà in grado di:

1. Descrivere il funzionamento dell'all-reduce ring-based e perché è bandwidth-optimal
2. Osservare le primitive collettive (`broadcast`, `all_reduce`, `all_gather`, `scatter`) con `torch.distributed`
3. Scrivere uno script PyTorch DDP che usa NCCL/gloo come backend collettivo
4. Lanciare un Custom Training Job multi-worker su Vertex AI
5. Confrontare empiricamente la scaling efficiency tra 1, 2 e 4 worker

---

## Prerequisiti

- Python 3.9+, PyTorch ≥ 2.0
- Lezione 6 completata (Custom Training Job su Vertex AI funzionante)
- Per la versione GCP: `gcloud` autenticato, progetto `test-project-493915`

```bash
pip install torch torchvision
python -c "import torch; import torch.distributed as dist; print('gloo:', dist.is_gloo_available())"
```

---

## Struttura

```
007-collective-communication/
├── dataset.py          # SyntheticDataset + GCSDataset + build_dataloader()
├── model.py            # MLP a tre strati con param_bytes() per il benchmark
├── train_ddp.py        # ⭐ Script principale: training DDP completo
├── ex1_primitives.py   # Esercizio 1: osservare le primitive collettive
├── ex3_benchmark.py    # Esercizio 3: benchmark di scaling efficiency
├── ex3_analyze.py      # Analisi dei risultati del benchmark
├── ex4_broadcast_check.py  # Esercizio 4 (opzionale): verifica broadcast DDP
├── Dockerfile          # Container per Vertex AI Custom Training Job
├── job_config.yaml     # Configurazione del job multi-worker
└── requirements.txt
```

---

## Esercizi locali (nessuna GPU richiesta)

### Esercizio 0 — Setup

```bash
pip install torch
python -c "import torch.distributed as dist; print('gloo:', dist.is_gloo_available())"
```

### Esercizio 1 — Primitive collettive

Osservare broadcast, reduce, all-reduce, all-gather e scatter con processi reali.

```bash
torchrun --nproc_per_node=2 ex1_primitives.py
torchrun --nproc_per_node=4 ex1_primitives.py
```

Cosa osservare:
- Dopo `broadcast`: tutti i rank hanno `[1.0, 2.0, 3.0, 4.0]`
- Dopo `all_reduce(SUM)` con 2 worker: `[3.0, 3.0, 3.0, 3.0]`  (1+2)
- Dopo `all_reduce(SUM)` con 4 worker: `[10.0, 10.0, 10.0, 10.0]` (1+2+3+4)

### Esercizio 2 — Training DDP completo ⭐

```bash
# Baseline: 1 processo (nessuna comunicazione collettiva)
torchrun --nproc_per_node=1 train_ddp.py

# 2 worker: DDP esegue all-reduce su ogni backward
torchrun --nproc_per_node=2 train_ddp.py

# 4 worker
torchrun --nproc_per_node=4 train_ddp.py
```

Cosa osservare nei log:
- La loss converge alla stessa traiettoria indipendentemente da `nproc_per_node`
  (prova che l'all-reduce mantiene la coerenza matematica)
- Il throughput (camp/s) aumenta con più worker (ma non linearmente)

### Esercizio 3 — Benchmark di scaling efficiency

```bash
torchrun --nproc_per_node=1 ex3_benchmark.py
torchrun --nproc_per_node=2 ex3_benchmark.py
torchrun --nproc_per_node=4 ex3_benchmark.py
python3 ex3_analyze.py
```

Output atteso (CPU locale con gloo):

```
Worker │ Tempo epoch │    Throughput │  Speedup │ Efficiency
────────────────────────────────────────────────────────────────────────
     1 │       X.XXXs │       YYYY/s  │   1.00×  │   100.0%
     2 │       X.XXXs │       YYYY/s  │   X.XX×  │    YY.Y%  ⚠ accettabile
     4 │       X.XXXs │       YYYY/s  │   X.XX×  │    YY.Y%  ⚠ accettabile
```

Su Vertex AI con GPU e NCCL l'efficienza sarà 85-95%.

### Esercizio 4 (opzionale) — Verifica broadcast DDP

```bash
torchrun --nproc_per_node=3 ex4_broadcast_check.py
```

Dimostra che `DDP(model)` esegue un broadcast silenzioso dei pesi da rank 0.

---

## Versione GCP — Vertex AI Custom Training Job

### 1. Build e push del container

```bash
PROJECT=test-project-493915
REGION=europe-west4
REPO=lab-repo
IMAGE=${REGION}-docker.pkg.dev/${PROJECT}/${REPO}/lab07-ddp:latest

docker build -t ${IMAGE} .
docker push ${IMAGE}
```

### 2. Lancio del job

```bash
gcloud ai custom-jobs create \
  --region=europe-west4 \
  --display-name=lab07-ddp-collective \
  --config=job_config.yaml
```

### 3. Monitoring

```bash
# Lista job
gcloud ai custom-jobs list --region=europe-west4

# Log in tempo reale
gcloud ai custom-jobs stream-logs <JOB_ID> --region=europe-west4
```

---

## Corrispondenza locale ↔ GCP

| Componente locale | Equivalente su Vertex AI |
|---|---|
| `torchrun --nproc_per_node=2` | `replicaCount: 2` in `workerPoolSpecs` |
| `backend='gloo'` | `backend='nccl'` (GPU) |
| `device=cpu` | `device=cuda` |
| Variabili iniettate da `torchrun` | Stesse variabili iniettate da Vertex AI |
| Socket loopback `127.0.0.1` | Rete VPC ad alta banda tra VM |

Il codice di `train_ddp.py` è **identico** in entrambi gli ambienti.
Cambia solo il launcher e il backend: `torchrun` → Vertex AI, `gloo` → `nccl`.

---

## Concetti chiave

- **All-reduce** = aggregazione globale senza nodo centrale; `⊕` deve essere associativa
- **Ring-based all-reduce**: Reduce-Scatter + All-Gather → volume `2(N-1)/N·|g|` per processo → bandwidth-optimal
- **DDP**: `loss.backward()` → NCCL esegue all-reduce → `optimizer.step()` aggiorna parametri coerenti su tutti i rank
- **DistributedSampler**: garantisce partizioni disgiunte del dataset; `set_epoch(epoch)` obbligatorio ad ogni epoch
- **Scaling efficiency**: `speedup / N × 100%`; < 100% a causa di overhead di comunicazione e sincronizzazione

---

## Lezione successiva

Lezione 8 — Fault tolerance e checkpointing: cosa succede se un nodo cade durante l'all-reduce? Come si ripristina il training senza ripartire da zero?
