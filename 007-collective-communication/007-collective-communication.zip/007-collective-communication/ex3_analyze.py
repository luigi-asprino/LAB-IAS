# =============================================================================
# ex3_analyze.py — Analisi dei risultati del benchmark
# =============================================================================
#
# Da eseguire DOPO aver completato i tre run di ex3_benchmark.py:
#
#   torchrun --nproc_per_node=1 ex3_benchmark.py
#   torchrun --nproc_per_node=2 ex3_benchmark.py
#   torchrun --nproc_per_node=4 ex3_benchmark.py
#   python3 ex3_analyze.py
#
# Stampa la tabella di scaling efficiency e spiega i risultati.
# Non richiede torch.distributed — è uno script Python normale.
# =============================================================================

import json
import os
import sys


def load_results(world_sizes: list[int]) -> dict[int, dict]:
    results = {}
    for w in world_sizes:
        fname = f"results_w{w}.json"
        if not os.path.exists(fname):
            print(f"⚠  File {fname} non trovato. Esegui prima:")
            print(f"   torchrun --nproc_per_node={w} ex3_benchmark.py")
        else:
            with open(fname) as f:
                results[w] = json.load(f)
    return results


def print_table(results: dict[int, dict]):
    if not results:
        print("Nessun risultato disponibile.")
        sys.exit(1)

    baseline = results[min(results.keys())]
    T1       = baseline["avg_epoch_s"]
    TP1      = baseline["throughput_sps"]

    # ── Tabella principale ─────────────────────────────────────────────────
    sep = "─" * 72
    print(f"\n{'RISULTATI BENCHMARK — Scaling Efficiency':^72}")
    print(sep)
    print(f"{'Worker':>8} │ {'Tempo epoch':>12} │ {'Throughput':>14} │ "
          f"{'Speedup':>8} │ {'Efficiency':>10}")
    print(sep)

    for w in sorted(results):
        r          = results[w]
        T_w        = r["avg_epoch_s"]
        TP_w       = r["throughput_sps"]
        speedup    = T1 / T_w
        efficiency = speedup / w * 100

        flag = ""
        if efficiency >= 90:
            flag = "✓ eccellente"
        elif efficiency >= 75:
            flag = "✓ buono"
        elif efficiency >= 50:
            flag = "⚠ accettabile"
        else:
            flag = "✗ basso overhead"

        print(f"{w:>8} │ {T_w:>11.3f}s │ {TP_w:>12.0f}/s │ "
              f"{speedup:>7.2f}× │ {efficiency:>8.1f}%  {flag}")

    print(sep)

    # ── Confronto con ideal ────────────────────────────────────────────────
    print(f"\n{'CONFRONTO CON SCALING IDEALE':^72}")
    print(sep)
    print(f"{'Worker':>8} │ {'Ideale':>12} │ {'Reale':>12} │ {'Overhead':>10}")
    print(sep)
    for w in sorted(results):
        r           = results[w]
        T_ideal     = T1 / w
        T_real      = r["avg_epoch_s"]
        overhead_ms = (T_real - T_ideal) * 1000
        print(f"{w:>8} │ {T_ideal:>11.3f}s │ {T_real:>11.3f}s │ "
              f"+{overhead_ms:>7.0f}ms")
    print(sep)


def print_interpretation(results: dict[int, dict]):
    """Stampa una spiegazione didattica dei risultati."""
    if len(results) < 2:
        return

    w_max    = max(results.keys())
    T1       = results[min(results.keys())]["avg_epoch_s"]
    T_N      = results[w_max]["avg_epoch_s"]
    speedup  = T1 / T_N
    eff      = speedup / w_max * 100

    print(f"\n{'INTERPRETAZIONE':^72}")
    print("─" * 72)

    model_kb = results[min(results.keys())].get("model_kb", "~388")
    print(f"""
Stai osservando T_iter = T_comp + T_comm con:
  • T_comp : tempo per forward + backward sul batch locale
  • T_comm : tempo per l'all-reduce NCCL/gloo sui gradienti

Con {w_max} worker e scaling efficiency {eff:.0f}%, circa il {100-eff:.0f}% del tempo
va in overhead di comunicazione e sincronizzazione.

Perché lo speedup non è {w_max}×:
  • Overhead loopback gloo (in locale) o latenza inter-nodo (su GCP)
  • Barriere di sincronizzazione: ogni rank aspetta il più lento
  • Legge di Amdahl: la parte seriale (logging, I/O) rimane costante
  • Competizione per i core CPU (in locale con gloo)

Su Vertex AI con GPU e NCCL:
  • NCCL usa NVLink/InfiniBand: banda 10-100× superiore al loopback CPU
  • Il backward pass delle ultime layer si sovrappone all'all-reduce
    delle prime layer (gradient bucketing di DDP)
  • Efficiency tipica: 85-95% su 2 GPU della stessa macchina
""")


def main():
    world_sizes = [1, 2, 4]
    results = load_results(world_sizes)
    results = {w: r for w, r in results.items() if r}  # filtra mancanti

    if not results:
        sys.exit(1)

    print_table(results)
    print_interpretation(results)

    print("\nFile disponibili per ulteriore analisi:")
    for w in sorted(results):
        print(f"  results_w{w}.json")


if __name__ == "__main__":
    main()
