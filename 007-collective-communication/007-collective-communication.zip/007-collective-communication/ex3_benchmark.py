# =============================================================================
# ex3_benchmark.py — Esercizio 3: Benchmark di scaling efficiency
# =============================================================================
#
# Obiettivo: misurare quantitativamente l'overhead dell'all-reduce e
# confrontare lo speedup reale con quello teorico (linear scaling).
#
# Lancio (ripetere per world_size=1, 2, 4):
#   torchrun --nproc_per_node=1 ex3_benchmark.py
#   torchrun --nproc_per_node=2 ex3_benchmark.py
#   torchrun --nproc_per_node=4 ex3_benchmark.py
#
# Poi analizzare con:
#   python3 ex3_analyze.py
#
# Output per run: results_w<N>.json (leggibile da ex3_analyze.py)
#
# Metriche calcolate:
#   T_epoch     : tempo medio per epoch (secondi)
#   throughput  : campioni processati per secondo (camp/s)
#   speedup     : T1 / TN rispetto al baseline a 1 worker
#   efficiency  : speedup / N × 100%  (100% = linear scaling perfetto)
#
# Cosa aspettarsi:
#   - In locale con gloo su CPU: efficiency ~50-80% con 2 worker
#     Motivo: overhead socket loopback + competizione per core CPU
#   - Su Vertex AI con nccl su GPU: efficiency ~85-95% con 2 GPU
#     Motivo: NCCL usa NVLink o banda dedicata, la GPU maschera la latenza
# =============================================================================

import json
import os
import time

import torch
import torch.distributed as dist
import torch.nn as nn
from torch.nn.parallel import DistributedDataParallel as DDP

from dataset import build_dataloader
from model import MLP


# =============================================================================
# Configurazione benchmark
# =============================================================================

N_SAMPLES   = int(os.environ.get("BENCH_N_SAMPLES",  "8000"))
BATCH_SIZE  = int(os.environ.get("BENCH_BATCH_SIZE", "256"))
N_EPOCHS    = int(os.environ.get("BENCH_N_EPOCHS",   "3"))    # 3 epoch per stabilizzare la media
N_FEATURES  = int(os.environ.get("N_FEATURES",       "128"))
LR          = float(os.environ.get("LR",             "0.05"))


# =============================================================================
# Setup / Teardown (identici a train_ddp.py)
# =============================================================================

def setup():
    backend = "nccl" if torch.cuda.is_available() else "gloo"
    dist.init_process_group(backend=backend, init_method="env://")
    rank       = dist.get_rank()
    world_size = dist.get_world_size()

    if torch.cuda.is_available():
        local_rank = int(os.environ.get("LOCAL_RANK", rank))
        device = torch.device(f"cuda:{local_rank}")
        torch.cuda.set_device(device)
    else:
        device = torch.device("cpu")

    return rank, world_size, device


def teardown():
    dist.destroy_process_group()


# =============================================================================
# Benchmark run
# =============================================================================

def run_benchmark(rank: int, world_size: int, device: torch.device) -> dict:
    """
    Esegue N_EPOCHS di training DDP e raccoglie le metriche di performance.

    Returns dict con: world_size, epoch_times, avg_epoch_s, throughput_sps
    """
    loader, dataset = build_dataloader(
        batch_size  = BATCH_SIZE,
        distributed = True,
        rank        = rank,
        world_size  = world_size,
    )

    model     = DDP(
        MLP(in_features=N_FEATURES, n_classes=2).to(device),
        device_ids=[device] if torch.cuda.is_available() else None
    )
    optimizer = torch.optim.SGD(model.parameters(), lr=LR, momentum=0.9)
    criterion = nn.CrossEntropyLoss()

    if rank == 0:
        inner = model.module
        print(f"\n[bench] world_size={world_size} | "
              f"{N_SAMPLES} campioni | "
              f"batch_size={BATCH_SIZE} | "
              f"modello={inner.param_bytes()//1024} KB all-reduce/iter")
        print(f"[bench] Riscaldamento...")

    # ── Warm-up: 1 epoch non misurata ────────────────────────────────────
    # Il primo epoch può essere più lento per inizializzazione lazy
    # (JIT compilation, allocazione CUDA, NCCL group init).
    loader.sampler.set_epoch(-1)
    for X, y in loader:
        X, y = X.to(device), y.to(device)
        optimizer.zero_grad()
        criterion(model(X), y).backward()
        optimizer.step()

    if rank == 0:
        print(f"[bench] Inizio misurazioni ({N_EPOCHS} epoch)...")

    # ── Epoch misurate ────────────────────────────────────────────────────
    epoch_times = []

    for epoch in range(N_EPOCHS):
        loader.sampler.set_epoch(epoch)
        model.train()

        # Sincronizzazione prima di avviare il timer:
        # senza questa barriera, i rank potrebbero iniziare l'epoch
        # in momenti diversi, rendendo i tempi non comparabili.
        dist.barrier()
        t0 = time.perf_counter()

        for X, y in loader:
            X, y = X.to(device), y.to(device)
            optimizer.zero_grad()
            criterion(model(X), y).backward()
            optimizer.step()

        # Sincronizzazione finale: garantisce che tutti i rank abbiano
        # completato il loro ultimo batch prima di fermare il timer.
        # Senza questa barriera, rank 0 potrebbe fermare il timer prima
        # che rank 1 abbia completato la comunicazione dell'ultimo batch.
        dist.barrier()
        t_epoch = time.perf_counter() - t0
        epoch_times.append(t_epoch)

        if rank == 0:
            throughput = N_SAMPLES / t_epoch
            print(f"  Epoch {epoch+1}/{N_EPOCHS}: {t_epoch:.3f}s  "
                  f"({throughput:.0f} camp/s)")

    avg_epoch   = sum(epoch_times) / len(epoch_times)
    throughput  = N_SAMPLES / avg_epoch

    return {
        "world_size":     world_size,
        "n_samples":      N_SAMPLES,
        "batch_size":     BATCH_SIZE,
        "n_epochs":       N_EPOCHS,
        "epoch_times":    epoch_times,
        "avg_epoch_s":    round(avg_epoch, 4),
        "throughput_sps": round(throughput, 1),
    }


# =============================================================================
# Salvataggio risultati e stampa tabella
# =============================================================================

def save_results(results: dict, world_size: int):
    fname = f"results_w{world_size}.json"
    with open(fname, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n[bench] Risultati salvati in {fname}")
    print(f"[bench] world_size={world_size} | "
          f"avg_epoch={results['avg_epoch_s']:.3f}s | "
          f"throughput={results['throughput_sps']:.0f} camp/s")


# =============================================================================
# Entry point
# =============================================================================

if __name__ == "__main__":
    rank, world_size, device = setup()
    try:
        results = run_benchmark(rank, world_size, device)
        if rank == 0:
            save_results(results, world_size)
    finally:
        teardown()
